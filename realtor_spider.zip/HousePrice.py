# coding:utf-8
# Author：Yalin Yang
# __file__ : HousePrice.py
# __time__ : 2018/11/12 17:14

import urllib.request

import requests

import random

import time

from fake_useragent import UserAgent

import re

from lxml import etree

url_first = 'https://www.realtor.com/realestateandhomes-search/Bronx_NY'

# proxy_support = urllib.request.ProxyHandler({'http': '167.114.102.230:80'})
# proxy_support = urllib.request.ProxyHandler({'http': '121.193.143.249:80'})
# proxy_support = urllib.request.ProxyHandler({'http':'106.46.136.112:808'})
proxy_support = urllib.request.ProxyHandler({'http':'65.126.127.202:37005'})

opener = urllib.request.build_opener(proxy_support)

opener.addheaders = [('User-Agent',
                      'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1866.237 Safari/537.36')]

# ua = UserAgent()
#
# opener.addheaders = [('User-Agent',
#                       ua.chrome)]


urllib.request.install_opener(opener)
resposne = urllib.request.urlopen(url_first)
html = resposne.read().decode('utf-8')
content = etree.HTML(html)

pages = int(content.xpath('///*[@id="ResultsPerPageBottom"]/nav/span/a/text()')[-1])
print("这个区域有" + str(pages) + "页")

for h in range(pages):
    index = url_first + '/pg-' + str(h+1)
    url = index
    print(url)
    # proxy_support = urllib.request.ProxyHandler({'http': '167.114.102.230:80'})
    # proxy_support = urllib.request.ProxyHandler({'http': '106.46.136.112:808'})
    proxy_support = urllib.request.ProxyHandler({'http': '65.126.127.202:37005'})

    opener = urllib.request.build_opener(proxy_support)

    opener.addheaders = [('User-Agent',
                          'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1866.237 Safari/537.36')]
    #
    # ua = UserAgent()
    #
    # opener.addheaders = [('User-Agent',
    #                       ua.chrome)]

    urllib.request.install_opener(opener)
    resposne = urllib.request.urlopen(url)
    html = resposne.read().decode('utf-8')
    content = etree.HTML(html)

    urllinks = content.xpath('//div[@class="photo-wrap "]/a/@href')
    sequence = content.xpath('//div[@class="save-wrap "]/@data-property-id')

    print("This page have " + str(len(sequence)) + " records")
    for i in range(len(urllinks)-1):
        urllinks[i] = 'https://www.realtor.com' + str(urllinks[i])

    # print(len(urllinks)-1)
    for j in range(len(urllinks) - 1):
        # print(urllinks[j])
        try:
            price = str(content.xpath('//*[@id="' + str(
                sequence[j]) + '"]/div/div/div[@class="price"]/span[@class="data-price"]/text()')[0])
            # print(price)
        except Exception as e:
            price = str(content.xpath('//*[@id="' + str(
                sequence[j]) + '"]/div/div/div[@class="price"]/span[@class="price-font-small"]/text()')[0])
        # print(price)
        try:
            bed = content.xpath('//*[@id="' + str(
                sequence[
                    j]) + '"]/div/ul[@class="prop-meta ellipsis"]/li[@data-label="property-meta-beds"]/span/text()')[0]
        except:
            bed = "No"
        try:
            bath = content.xpath('//*[@id="' + str(
                sequence[
                    j]) + '"]/div/ul[@class="prop-meta ellipsis"]/li[@data-label="property-meta-baths"]/span/text()')[0]
        except Exception as e:
            bath = "No"
        try:
            area = str(content.xpath('//*[@id="' + str(
                sequence[
                    j]) + '"]/div/ul[@class="prop-meta ellipsis"]/li[@data-label="property-meta-sqft"]/span/text()')[
                           0])
        except Exception as e:
            area = 'No'
        try:
            pet = content.xpath(
                '//div/ul[@class="prop-meta ellipsis"]/li[@data-label="property-meta-pets"]/span[@class="data-value"]/text()')[
                j]
        except Exception as e:
            pet = 'No'
        try:
            community = str(content.xpath('//*[@id="' + str(
                sequence[j]) + '"]/div/div[@class="address ellipsis"]/a/span[@class ="listing-community"]/text()')[0])
            # print(community)
        except Exception as e:
            community = 'No'
        try:
            street_address = \
                content.xpath('//*[@id="' + str(
                    sequence[j]) + '"]/div/div/a/span[@class ="listing-street-address"]/text()')[0]
        except Exception as e:
            street_address = 'No'
        try:
            city = content.xpath('//*[@id="' + str(
                sequence[j]) + '"]/div/div[@class="address ellipsis"]/a/span[@class ="listing-city"]/text()')[0]
        except Exception as e:
            city = 'No'
        try:
            region = content.xpath('//*[@id="' + str(
                sequence[j]) + '"]/div/div[@class="address ellipsis"]/a/span[@class="listing-region"]/text()')[0]
        except Exception as e:
            region = 'No'

        try:
            postal = content.xpath('//*[@id="' + str(
                sequence[j]) + '"]/div/div[@class="address ellipsis"]/a/span[@class="listing-postal"]/text()')[0]
        except Exception as e:
            postal = 'No'

        with open('Bronx.txt', 'a', encoding='utf-8') as f:
            # print(community + ' @ ' + street_address + ' @ ' + city + ' @ ' + region + ' @ ' + postal + ' @ ' + price
            #                 + ' @ ' + bed + ',' + bath + ' @ ' + area + ' @ ' + pet + ' @ ' + urllinks[j] + '\n')
            f.write(community + ' @ ' + street_address + ' @ ' + city + ' @ ' + region + ' @ ' + postal + ' @ ' + price
                    + ' @ ' + bed + ',' + bath + ' @ ' + area + ' @ ' + pet + ' @ ' + urllinks[j] + '\n')
    print('writing work has done!continue the next page')
    time.sleep(random.randint(1,5))

print('Done')