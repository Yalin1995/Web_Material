# Author：Yalin Yang
# __file__ : 2.py
# __time__ : 2018/9/23 17:02

from openpyxl import Workbook
import os

wb = Workbook()
wz = wb.active
wz['A1'] = 'Community'
wz['B1'] = 'Street_Address'
wz['C1'] = 'City'
wz['D1'] = 'Region'
wz['E1'] = 'Postal'
wz['F1'] = 'Price'
wz['G1'] = 'Bed/Bath'
wz['H1'] = 'Area'
wz['I1'] = 'Pet'
wz['J1'] = 'URL'

file = r'.\Bronx.txt'
f = open(file , encoding='utf-8', errors='ignore')
line = f.readline()
print(line)
while line :
    wz.append(list(line.split('@')))
    line = f.readline()

output = os.path.basename(file).split(".")[0] + '.xlsx'
print(output)
wb.save(output)
print('over')
