# coding:utf-8
# Author：Yalin Yang
# __file__ : Area_Price.py
# __time__ : 2019/1/15 16:49

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import csv
from numpy import array

learning_rate = 0.5
training_epochs = 10000
display_step = 1000

# get the data for training
y_data = []
x_data = []

with open("./Manhattan.csv", newline='') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        if (("NA" not in row['Area'])):
            try:
                y_data.append(np.float32(row['Price']))
                x_data.append(np.float32(row["Area"]))
            except:
                continue


train_Y = array(y_data).reshape(len(y_data),1)
train_X = array(x_data).reshape(len(x_data),1)
n_samples = train_X.shape[0]

# create placeholder
X = tf.placeholder("float")
Y = tf.placeholder("float")

# Set model weights and bias
rng = np.random
W = tf.Variable(rng.randn(), name="weight")
b = tf.Variable(rng.randn(), name="bias")

# Construct a linear model
pred = tf.add(tf.multiply(X, W), b)

# Define loss
cost = tf.sqrt(tf.reduce_mean(tf.square(pred-Y)))
# using AdamOptimizer
optimizer = tf.train.AdamOptimizer(learning_rate).minimize(cost)

init = tf.global_variables_initializer()

fig = plt.figure()
ax = fig.add_subplot(1,1,1)
plt.plot(train_X, train_Y, 'ro', label='Original data')
plt.ion()
plt.legend()
plt.show()

# Launch the graph
with tf.Session() as sess:
    sess.run(init)
    # Fit all training data
    for epoch in range(training_epochs):
        sess.run(optimizer, feed_dict={X: train_X, Y:train_Y})
        if (epoch + 1) % display_step == 0:
            c = sess.run(cost, feed_dict={X: train_X, Y: train_Y})
            print("Epoch:", '%04d' % (epoch + 1), "cost=", "{:.9f}".format(c), \
                  "W=", sess.run(W), "b=", sess.run(b))
            try:
                # 每次显示后均去除预测线段
                ax.lines.remove(lines[0])
            except Exception:
                pass
            prediction_value = sess.run(pred, feed_dict={X: train_X, Y:train_Y})
            lines = ax.plot(x_data, prediction_value,"b-", lw=2, label='Fitted line')
            plt.legend()
            plt.pause(0.5)
    print("Optimization Finished!")

    training_cost = sess.run(cost, feed_dict={X: train_X, Y: train_Y})
    print("Training cost=", training_cost, "W=", sess.run(W), "b=", sess.run(b), '\n')

    # Graphic display（画图）
    # plt.plot(train_X, train_Y, 'ro', label='Original data')
    # plt.plot(train_X, sess.run(W) * train_X + sess.run(b), label='Fitted line')
    plt.legend()
    # plt.show()
